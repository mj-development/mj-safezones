----------------------------------------------------
---------<!>----- MJ | DEVELOPMENT -----<!>---------
----------------------------------------------------

fx_version 'cerulean'
game 'gta5'

author 'MJ DEVELOPMENT'
description 'SafeZones Script for QBCore'
version '1.0.0'

escrow_ignore {
    'config.lua',  
}
shared_scripts {
    'config.lua'
}
client_scripts {
    'client/main.lua'
}

lua54 'yes'


-- GITHUB -- https://github.com/mj-development
-- TEBEX STORE -- https://mjdevelopment.tebex.io
-- YOUTUBE -- https://www.youtube.com/@mjdevelopment