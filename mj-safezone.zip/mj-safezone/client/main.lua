local QBCore = exports['qb-core']:GetCoreObject()
local inSafeZone = false
local currentZone = nil
local godmode = false

-- Function to check if player is police
local function IsPolice()
    local Player = QBCore.Functions.GetPlayerData()
    if Player.job and Config.PoliceJobs[Player.job.name] then
        return true
    end
    return false
end

-- Function to check if player is in any safe zone
local function IsPlayerInSafeZone(playerCoords)
    for zoneName, zone in pairs(Config.SafeZones) do
        local distance = #(playerCoords - zone.coords)
        if distance <= zone.radius then
            return true, zoneName
        end
    end
    return false, nil
end

-- Function to enable safe zone protection
local function EnableSafeZone()
    local ped = PlayerPedId()
    
    -- Enable god mode
    SetEntityInvincible(ped, true)
    SetEntityProofs(ped, true, true, true, true, true, true, true, true)
    
    -- Disable weapons
    SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
    godmode = true
end

-- Function to disable safe zone protection
local function DisableSafeZone()
    local ped = PlayerPedId()
    
    -- Disable god mode
    SetEntityInvincible(ped, false)
    SetEntityProofs(ped, false, false, false, false, false, false, false, false)
    godmode = false
end

-- Function to play zone notification
local function PlayZoneNotification(entering, zoneName)
    if entering then
        if Config.Notifications.enter.sound then
            TriggerServerEvent('InteractSound_SV:PlayOnOne', 'enter', 0.5)
        end
        QBCore.Functions.Notify(Config.SafeZones[zoneName].message, Config.Notifications.enter.type, Config.Notifications.enter.duration)
    else
        if Config.Notifications.exit.sound then
            TriggerServerEvent('InteractSound_SV:PlayOnOne', 'exit', 0.5)
        end
        QBCore.Functions.Notify("You've left the safe zone", Config.Notifications.exit.type, Config.Notifications.exit.duration)
    end
end

-- Warning text display thread
CreateThread(function()
    while true do
        Wait(0)
        if inSafeZone and Config.WarningText.enabled then
            SetTextScale(Config.WarningText.scale, Config.WarningText.scale)
            SetTextFont(4)
            SetTextProportional(1)
            SetTextColour(Config.WarningText.color.r, Config.WarningText.color.g, Config.WarningText.color.b, 255)
            SetTextEntry("STRING")
            SetTextCentre(1)
            AddTextComponentString(Config.WarningText.text)
            DrawText(Config.WarningText.position.x, Config.WarningText.position.y)
        end
    end
end)

-- Main thread for checking safe zones
CreateThread(function()
    while true do
        Wait(1000)
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local isInZone, zoneName = IsPlayerInSafeZone(coords)

        if isInZone and not inSafeZone then
            inSafeZone = true
            currentZone = zoneName
            EnableSafeZone()
            PlayZoneNotification(true, zoneName)
        elseif not isInZone and inSafeZone then
            inSafeZone = false
            currentZone = nil
            DisableSafeZone()
            PlayZoneNotification(false)
        end
    end
end)

-- Debug visualization thread
CreateThread(function()
    while true do
        Wait(0)
        if Config.Debug then
            for zoneName, zone in pairs(Config.SafeZones) do
                DrawMarker(28, zone.coords.x, zone.coords.y, zone.coords.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 
                    zone.radius, zone.radius, zone.radius, 0, 255, 0, 50, false, false, 2, nil, nil, false)
            end
        end
    end
end)

CreateThread(function()
    while true do
        Wait(0)
        if inSafeZone and not IsPolice() then  -- Only restrict if not police
            DisableControlAction(0, 24, true) -- Disable attack
            DisableControlAction(0, 25, true) -- Disable aim
            DisableControlAction(0, 47, true) -- Disable weapon
            DisableControlAction(0, 58, true) -- Disable weapon
            DisableControlAction(0, 140, true) -- Disable melee attack
            DisableControlAction(0, 141, true) -- Disable melee attack
            DisableControlAction(0, 142, true) -- Disable melee attack
            DisableControlAction(0, 143, true) -- Disable melee attack
            DisableControlAction(0, 263, true) -- Disable melee attack (R)
            DisableControlAction(0, 264, true) -- Disable melee attack
            DisableControlAction(0, 257, true) -- Disable melee attack
            DisablePlayerFiring(PlayerId(), true) -- Disable firing
            
            -- Remove all weapons temporarily if player somehow gets them
            local ped = PlayerPedId()
            if IsPedArmed(ped, 7) then
                SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
            end
            
            -- Disable melee damage
            SetPedMaxHealth(ped, 100)
            SetEntityMaxHealth(ped, 100)
        end
    end
end)

-- Function to enable safe zone protection (modified for police)
local function EnableSafeZone()
    local ped = PlayerPedId()
    
    if not IsPolice() then  -- Only enable full protection if not police
        -- Enable god mode for non-police
        SetEntityInvincible(ped, true)
        SetEntityProofs(ped, true, true, true, true, true, true, true, true)
        SetCurrentPedWeapon(ped, GetHashKey('WEAPON_UNARMED'), true)
    else
        -- Partial protection for police (optional)
        SetEntityProofs(ped, false, true, true, false, true, true, true, false)
    end
    
    godmode = true
end

-- Prevent vehicle damage in safe zones
CreateThread(function()
    while true do
        Wait(0)
        if inSafeZone then
            local ped = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(ped, false)
            
            if vehicle ~= 0 then
                SetEntityInvincible(vehicle, true)
                SetVehicleEngineCanDegrade(vehicle, false)
                SetVehicleCanBreak(vehicle, false)
                SetVehicleCanBeVisiblyDamaged(vehicle, false)
            end
        end
    end
end)